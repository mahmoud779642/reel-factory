# Reel Factory

Mobile-first Arabic workflow for creating 60-second Egyptian-Arabic reels.

## Current MVP
- Mobile PWA interface (Arabic RTL).
- Cloudflare Worker API for Gemini script generation.
- Pixabay video search.
- Safe server-side API keys (never put keys in browser code).
- Project JSON export for the rendering stage.

## Important
This first build creates the script and gathers footage candidates. It does **not yet render a finished MP4**. Rendering, Egyptian female TTS, AI image generation, subtitles, music and final MP4 export are the next integration stage. Do not advertise this MVP as a finished automatic video generator.

## Deploy the interface
1. Upload the contents of this repository to GitHub.
2. In GitHub: Settings → Pages → Build and deployment → Deploy from a branch → `main` → `/public`.
3. The PWA is available at the GitHub Pages URL.

## Deploy the API
1. Create a Cloudflare account and a Worker.
2. Paste `worker/index.js` into the Worker editor and deploy.
3. Add Worker secrets:
   - `GEMINI_API_KEY`
   - `PIXABAY_API_KEY`
4. Set Worker variable:
   - `ALLOWED_ORIGIN` = your GitHub Pages URL, e.g. `https://USERNAME.github.io`
5. In `public/app.js`, set `API_BASE` to your Worker URL.
6. Redeploy Pages.

## API
- `GET /health`
- `POST /api/generate` with `{ "idea": "..." }`
- `POST /api/search-footage` with `{ "queries": ["..."] }`

## Security
- Never commit API keys.
- Keep the repository private if preferred.
- Rotate any key that was accidentally committed or shared.
