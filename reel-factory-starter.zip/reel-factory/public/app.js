// Set this to the deployed Cloudflare Worker URL, e.g. https://reel-factory-api.example.workers.dev
const API_BASE = "";
const $ = (id) => document.getElementById(id);
const idea = $("idea");
idea.addEventListener("input", () => $("count").textContent = `${idea.value.length} / 700`);

let latestProject = null;
function showStatus(message, error=false){$("status").classList.remove("hidden","error");$("status").classList.toggle("error",error);$("status").textContent=message;}
function escapeHtml(s=""){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}

$("generate").addEventListener("click", async () => {
  const text = idea.value.trim();
  if(!text){showStatus("اكتب فكرة الفيديو الأول.",true);return;}
  if(!API_BASE){showStatus("الواجهة جاهزة، لكن لم يتم ربط Worker API بعد. اتبع خطوات README لإعداد API_BASE.",true);return;}
  $("generate").disabled=true; $("result").classList.add("hidden");
  try{
    showStatus("بنكتب السيناريو ونقسمه لمشاهد...");
    const res=await fetch(`${API_BASE}/api/generate`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({idea:text})});
    const data=await res.json(); if(!res.ok) throw new Error(data.error||"تعذر إنشاء السيناريو");
    showStatus("السيناريو جاهز. بنبحث عن لقطات واقعية...");
    const queries=(data.scenes||[]).map(s=>s.stock_query).filter(Boolean).slice(0,6);
    let footage=[];
    if(queries.length){
      const fr=await fetch(`${API_BASE}/api/search-footage`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({queries})});
      const fd=await fr.json(); if(fr.ok) footage=fd.results||[];
    }
    latestProject={created_at:new Date().toISOString(),idea:text,...data,footage};
    render(latestProject); $("result").classList.remove("hidden");
    showStatus("تم تجهيز السيناريو واللقطات المرشحة. تصدير MP4 والصوت الآلي قيد المرحلة التالية.");
  }catch(e){showStatus(e.message||"حدث خطأ غير متوقع.",true);}
  finally{$("generate").disabled=false;}
});
function render(p){
  $("script").textContent=p.script||"";
  $("scenes").innerHTML=(p.scenes||[]).map((s,i)=>`<div class="scene"><b>المشهد ${i+1} · ${escapeHtml(s.duration||"")}</b><p>${escapeHtml(s.visual||"")}</p><small>بحث الفيديو: ${escapeHtml(s.stock_query||"")}</small></div>`).join("");
  $("footage").innerHTML=(p.footage||[]).map(v=>`<div class="clip">${v.thumbnail?`<img src="${escapeHtml(v.thumbnail)}" loading="lazy">`:""}<div><b>${escapeHtml(v.tags||"لقطة فيديو")}</b><p><small>${escapeHtml(v.duration||"")} ثانية</small></p><a href="${escapeHtml(v.page_url||"#")}" target="_blank" rel="noopener">فتح المصدر</a></div></div>`).join("")||"<p class='muted'>لم يتم العثور على لقطات.</p>";
}
$("copy").addEventListener("click",async()=>{if(latestProject){await navigator.clipboard.writeText(latestProject.script||"");$("copy").textContent="تم النسخ";}});
$("export").addEventListener("click",()=>{if(!latestProject)return;const blob=new Blob([JSON.stringify(latestProject,null,2)],{type:"application/json"});const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="reel-project.json";a.click();URL.revokeObjectURL(a.href);});
