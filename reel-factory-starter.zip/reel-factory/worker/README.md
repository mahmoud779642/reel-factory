# Cloudflare Worker setup

Create a Worker and paste `index.js`.

Add secrets using Worker → Settings → Variables and Secrets:
- `GEMINI_API_KEY` (Secret)
- `PIXABAY_API_KEY` (Secret)

Add plain-text variable:
- `ALLOWED_ORIGIN` = exact Pages origin, e.g. `https://mahmoud779642.github.io`

After deploy, test `https://YOUR-WORKER.workers.dev/health`.

Do not expose these secrets in `public/app.js`.
