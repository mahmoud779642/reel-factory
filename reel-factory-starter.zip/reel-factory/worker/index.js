export default {
  async fetch(request, env) {
    const origin = request.headers.get("Origin") || "";
    const allowed = env.ALLOWED_ORIGIN || "";
    const headers = {
      "Access-Control-Allow-Origin": allowed && origin === allowed ? origin : allowed || "*",
      "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
      "Content-Type": "application/json; charset=utf-8",
      "Vary": "Origin"
    };
    if (request.method === "OPTIONS") return new Response(null,{headers});
    const url = new URL(request.url);
    try {
      if (url.pathname === "/health") return Response.json({ok:true,service:"reel-factory-api"},{headers});
      if (url.pathname === "/api/generate" && request.method === "POST") {
        const {idea} = await request.json();
        if (!idea || typeof idea !== "string" || idea.trim().length < 5) return Response.json({error:"اكتب فكرة أوضح."},{status:400,headers});
        if (!env.GEMINI_API_KEY) return Response.json({error:"لم يتم إعداد GEMINI_API_KEY في Worker Secrets."},{status:500,headers});
        const prompt = `اكتب فيديو قصير مدته 60 ثانية باللهجة المصرية الطبيعية بأسلوب ساخر نفسي: ابدأ وكأنك تقنع المشاهد بسلوك ضار، ثم اكشف التناقض والضرر بذكاء. لا تستخدم ادعاءات واقعية غير موثقة. المطلوب JSON فقط بالشكل: {"title":"...","script":"نص التعليق الصوتي كاملًا باللهجة المصرية","scenes":[{"duration":"0-8 ث","visual":"وصف بصري واضح للمشهد","stock_query":"عبارة بحث إنجليزية قصيرة لفيديو ستوك"}]}. أنشئ 6 إلى 8 مشاهد مجموعها 60 ثانية. لا تضف تعليقًا أو Markdown خارج JSON. الفكرة: ${idea.trim()}`;
        const response = await fetch("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key="+encodeURIComponent(env.GEMINI_API_KEY),{
          method:"POST",headers:{"Content-Type":"application/json"},
          body:JSON.stringify({contents:[{parts:[{text:prompt}]}],generationConfig:{responseMimeType:"application/json",temperature:0.8}})
        });
        const result = await response.json();
        if (!response.ok) return Response.json({error:result.error?.message||"Gemini API error"},{status:502,headers});
        const raw=result.candidates?.[0]?.content?.parts?.map(p=>p.text||"").join("")||"";
        let parsed; try { parsed=JSON.parse(raw); } catch { return Response.json({error:"تعذر قراءة JSON من Gemini. حاول مرة أخرى."},{status:502,headers}); }
        return Response.json(parsed,{headers});
      }
      if (url.pathname === "/api/search-footage" && request.method === "POST") {
        if (!env.PIXABAY_API_KEY) return Response.json({error:"لم يتم إعداد PIXABAY_API_KEY في Worker Secrets."},{status:500,headers});
        const {queries=[]}=await request.json();
        const results=[];
        for (const q of queries.slice(0,6)) {
          const endpoint=`https://pixabay.com/api/videos/?key=${encodeURIComponent(env.PIXABAY_API_KEY)}&q=${encodeURIComponent(q)}&per_page=3&safesearch=true`;
          const r=await fetch(endpoint); const data=await r.json();
          if(r.ok) for(const hit of (data.hits||[]).slice(0,3)){
            const v=hit.videos?.medium||hit.videos?.small||hit.videos?.tiny;
            if(v) results.push({tags:hit.tags,thumbnail:hit.userImageURL||"",duration:hit.duration,page_url:hit.pageURL,video_url:v.url});
          }
        }
        return Response.json({results:results.slice(0,18)},{headers});
      }
      return Response.json({error:"Not found"},{status:404,headers});
    } catch (e) {
      return Response.json({error:e.message||"Internal error"},{status:500,headers});
    }
  }
};
